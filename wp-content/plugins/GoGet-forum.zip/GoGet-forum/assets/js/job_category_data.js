data['job_category_data'] = [
    {
        id: 'UIUX / 視覺設計 Arts and Design',
        text: 'UIUX / 視覺設計 Arts and Design'
    },
    {
        id: '人資 Human Resource',
        text: '人資 Human Resource'
    },
    {
        id: '其他 Others',
        text: '其他 Others'
    },
    {
        id: '品管測試 Quality Control and Testing',
        text: '品管測試 Quality Control and Testing'
    },
    {
        id: '商業開發 Business Development',
        text: '商業開發 Business Development'
    },
    {
        id: '媒體公關 Public Relations',
        text: '媒體公關 Public Relations'
    },
    {
        id: '學術研究 Academic Research',
        text: '學術研究 Academic Research'
    },
    {
        id: '客戶服務 Customer Services',
        text: '客戶服務 Customer Services'
    },
    {
        id: '工程與研發 Engineering and R&D',
        text: '工程與研發 Engineering and R&D'
    },
    {
        id: '市場分析 Business Analysis',
        text: '市場分析 Business Analysis'
    },
    {
        id: '成長駭客 Growth Hacking',
        text: '成長駭客 Growth Hacking'
    },
    {
        id: '採購 Merchandising',
        text: '採購 Merchandising'
    },
    {
        id: '攝影 / 影音製作 Video Editing',
        text: '攝影 / 影音製作 Video Editing'
    },
    {
        id: '教育 / 教學 Education',
        text: '教育 / 教學 Education'
    },
    {
        id: '會計 Accounting',
        text: '會計 Accounting'
    },
    {
        id: '法務 Legal',
        text: '法務 Legal'
    },
    {
        id: '營運 Operations',
        text: '營運 Operations'
    },
    {
        id: '產品 / 專案管理 Product and Project Management',
        text: '產品 / 專案管理 Product and Project Management'
    },
    {
        id: '經營管理 Business and Management',
        text: '經營管理 Business and Management'
    },
    {
        id: '編輯 / 內容經營 Social Media Management',
        text: '編輯 / 內容經營 Social Media Management'
    },
    {
        id: '行政 Administrative',
        text: '行政 Administrative'
    },
    {
        id: '行銷企劃 / 社群經營 Marketing',
        text: '行銷企劃 / 社群經營 Marketing'
    },
    {
        id: '財務 Finance',
        text: '財務 Finance'
    },
    {
        id: '資料科學 Data Science and Analytics',
        text: '資料科學 Data Science and Analytics'
    },
    {
        id: '通路開發 Channel Development',
        text: '通路開發 Channel Development'
    },
    {
        id: '銷售服務 Sales',
        text: '銷售服務 Sales'
    },
    {
        id: '顧問服務 Consulting',
        text: '顧問服務 Consulting'
    }
];