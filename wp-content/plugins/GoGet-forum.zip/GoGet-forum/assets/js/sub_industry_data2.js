data['sub_industry_data2'] = [{
    id: '',
    text: '(無)',
}, {
    id: 0,
    text: '金融',
    children: [{
        id: '金融保險',
        text: '金融保險',
    },
    {
        id: '投資理財',
        text: '投資理財',
    },
    ]
}, {
    id: 1,
    text: '商業',
    children: [{
        id: '法律服務',
        text: '法律服務',
    },
    {
        id: '會計服務',
        text: '會計服務',
    },
    {
        id: '顧問服務',
        text: '顧問服務',
    },
    {
        id: '人力仲介',
        text: '人力仲介',
    }
    ]
}, {
    id: 2,
    text: '零售',
    children: [{
        id: '批發零售',
        text: '批發零售',
    },
    ]
}, {
    id: 3,
    text: '科技',
    children: [{
        id: '軟體網路',
        text: '軟體網路',
    },
    {
        id: '電信通訊',
        text: '電信通訊',
    },
    {
        id: '電子商務',
        text: '電子商務',
    },
    {
        id: '半導體業',
        text: '半導體業',
    },
    {
        id: '零件代工',
        text: '零件代工',
    },
    {
        id: '其他科技',
        text: '其他科技',
    }
    ]
}, {
    id: 4,
    text: '新創',
    children: [{
        id: '新創產業',
        text: '新創產業',
    },
    ]
}, {
    id: 5,
    text: '其它',
    children: [{
        id: '物流倉儲',
        text: '物流倉儲',
    },
    {
        id: '餐飲旅遊',
        text: '餐飲旅遊',
    },
    {
        id: '醫藥生技',
        text: '醫藥生技',
    },
    {
        id: '藝文教育',
        text: '藝文教育',
    },
    {
        id: '傳播媒體',
        text: '傳播媒體',
    },
    {
        id: '廣告行銷',
        text: '廣告行銷',
    },
    {
        id: '政治社福',
        text: '政治社福',
    },
    {
        id: '學術研究',
        text: '學術研究',
    },
    {
        id: '其他產業',
        text: '其他產業',
    }
    ]
}];