<?php 

namespace Bitpay\Client;

class ArgumentException extends \Exception
{

}
